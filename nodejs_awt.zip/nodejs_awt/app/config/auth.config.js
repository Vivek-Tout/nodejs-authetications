module.exports = {
  secret: "vivek-secret-key"
};
